"""
Prompt templates for Episodic IPD LLM Agents
Uses neutral language to allow cooperation to emerge naturally
"""

from typing import List, Dict


SYSTEM_PROMPT = """You are participating in a repeated exchange with another participant across multiple periods.

Each round, you choose: COOPERATE or DEFECT
The other participant also chooses.

Outcomes:
- Both COOPERATE: You get 3 points, other gets 3 points
- You COOPERATE, other DEFECTS: You get 0 points, other gets 5 points
- You DEFECT, other COOPERATES: You get 5 points, other gets 0 points
- Both DEFECT: You get 1 point, other gets 1 point

YOUR GOAL: Accumulate as many points as possible across all periods.

You will interact for multiple periods. After each period, you can reflect on 
what happened and adjust your approach. Learn from experience to improve your 
outcomes over time.

RESPONSE FORMAT:
Provide thoughtful reasoning about your choice in 2-3 complete sentences.
- What patterns do you observe in the recent interactions?
- Why are you choosing to cooperate or defect?
- What outcome do you expect?

When discussing actions in your reasoning, use lowercase words ("cooperate", "defect").

Then, on its own line, state your final choice in all capitals: COOPERATE or DEFECT

EXAMPLE RESPONSE:
"we've cooperated for three rounds and both earned 3 points each time. this seems 
to be working well for both of us. i'll continue to cooperate since it's mutually 
beneficial.

COOPERATE"

DO NOT just write a single word like "cooperate" or "defect" as your reasoning. 
Always explain your thinking in complete sentences.
"""


def format_round_prompt(
    round_num: int,
    episode_num: int,
    history: List[Dict],
    my_score: int,
    opp_score: int,
    window_size: int = 10
) -> str:
    """Format prompt for a single round within an episode"""
    
    if round_num == 0:
        return f"""PERIOD {episode_num + 1}, ROUND 1:
This is the first round of this period.

What is your choice?"""
    
    # Format recent history
    prompt = f"PERIOD {episode_num + 1}, ROUND {round_num + 1}:\n\n"
    prompt += f"Your total points: {my_score}\n"
    prompt += f"Other's total points: {opp_score}\n\n"
    prompt += "Recent interactions:\n"
    
    # Show last N rounds
    recent_history = history[-window_size:] if len(history) > window_size else history
    start_round = len(history) - len(recent_history) + 1
    
    for i, round_data in enumerate(recent_history, start=start_round):
        my_action = round_data['my_action'].lower()
        opp_action = round_data['opp_action'].lower()
        my_payoff = round_data['my_payoff']
        opp_payoff = round_data['opp_payoff']
        
        prompt += f"  Round {i}: You {my_action}d, Other {opp_action}d "
        prompt += f"(You: +{my_payoff}, Other: +{opp_payoff})\n"
    
    if len(history) > window_size:
        prompt += f"\n(Showing last {window_size} rounds of {len(history)} total)\n"
    
    prompt += "\nWhat is your choice?"
    
    return prompt


def format_episode_reflection_prompt(
    episode_num: int,
    history: List[Dict],
    my_score: int,
    opp_score: int,
    rounds_in_episode: int,
    reflection_type: str = "standard",
    include_statistics: bool = True
) -> str:
    """
    Format reflection prompt at end of episode
    
    Args:
        episode_num: Current episode number (0-indexed)
        history: Episode history
        my_score: Agent's score this episode
        opp_score: Opponent's score this episode
        rounds_in_episode: Number of rounds in the episode
        reflection_type: "minimal", "standard", or "detailed"
        include_statistics: Whether to include computed statistics
    """
    
    # Calculate statistics
    my_cooperations = sum(1 for r in history if r['my_action'] == 'COOPERATE')
    opp_cooperations = sum(1 for r in history if r['opp_action'] == 'COOPERATE')
    my_avg = my_score / len(history) if history else 0
    
    if reflection_type == "minimal":
        prompt = f"""PERIOD {episode_num + 1} COMPLETE

Your points: {my_score}
Other's points: {opp_score}
"""
        return prompt
    
    elif reflection_type == "standard":
        prompt = f"""PERIOD {episode_num + 1} COMPLETE (Rounds 1-{rounds_in_episode})

Your points this period: {my_score}
Other's points this period: {opp_score}
"""
        
        if include_statistics:
            prompt += f"""
Your average: {my_avg:.2f} points per round
Your choices: {my_cooperations} cooperate, {len(history) - my_cooperations} defect
Other's choices: {opp_cooperations} cooperate, {len(history) - opp_cooperations} defect
"""
        
        prompt += """
What happened this period:
"""
        
        # Show all rounds in the episode
        for i, round_data in enumerate(history, start=1):
            my_action = round_data['my_action']
            opp_action = round_data['opp_action']
            my_payoff = round_data['my_payoff']
            opp_payoff = round_data['opp_payoff']
            prompt += f"Round {i}: You {my_action}, Other {opp_action} (+{my_payoff}, +{opp_payoff})\n"
        
        prompt += "\nAs you continue to the next period, what are you thinking?\n"
        return prompt
    
    else:  # detailed
        prompt = f"""PERIOD {episode_num + 1} COMPLETE (Rounds 1-{rounds_in_episode})

OUTCOMES:
Your points this period: {my_score}
Other's points this period: {opp_score}

PERFORMANCE:
Your average: {my_avg:.2f} points per round
Theoretical range: 0 to 5 points per round
Your choices: {my_cooperations} cooperate ({my_cooperations/len(history)*100:.1f}%), {len(history) - my_cooperations} defect
Other's choices: {opp_cooperations} cooperate ({opp_cooperations/len(history)*100:.1f}%), {len(history) - opp_cooperations} defect

WHAT HAPPENED:
"""
        
        # Show all rounds
        for i, round_data in enumerate(history, start=1):
            my_action = round_data['my_action']
            opp_action = round_data['opp_action']
            my_payoff = round_data['my_payoff']
            opp_payoff = round_data['opp_payoff']
            prompt += f"Round {i}: You {my_action}, Other {opp_action} (You: +{my_payoff}, Other: +{opp_payoff})\n"
        
        prompt += "\nReflect on this period and consider your approach for the next period.\n"
        return prompt


def extract_decision(response: str) -> str:
    """Extract COOPERATE or DEFECT from LLM response"""
    response_upper = response.upper()
    
    # Check last line first (this is where the decision should be)
    lines = [line.strip() for line in response.strip().split('\n') if line.strip()]
    if lines:
        last_line = lines[-1]
        # Only check the last line for exact matches
        if last_line == 'COOPERATE':
            return 'COOPERATE'
        if last_line == 'DEFECT':
            return 'DEFECT'
        # Also accept if last line contains only the word
        if 'COOPERATE' in last_line and 'DEFECT' not in last_line:
            return 'COOPERATE'
        if 'DEFECT' in last_line and 'COOPERATE' not in last_line:
            return 'DEFECT'
    
    # Fallback: search whole response from end to beginning
    for line in reversed(lines):
        line_upper = line.upper()
        if line_upper == 'COOPERATE' or (line_upper.endswith('COOPERATE') and 'DEFECT' not in line_upper):
            return 'COOPERATE'
        if line_upper == 'DEFECT' or (line_upper.endswith('DEFECT') and 'COOPERATE' not in line_upper):
            return 'DEFECT'
    
    # If still not found, check if one appears and not the other
    has_cooperate = 'COOPERATE' in response_upper
    has_defect = 'DEFECT' in response_upper
    
    if has_cooperate and not has_defect:
        return 'COOPERATE'
    if has_defect and not has_cooperate:
        return 'DEFECT'
    
    # Ambiguous
    return None
